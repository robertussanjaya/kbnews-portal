<div class="container">
	<div class="row">
		<div class="col-sm-10 ml-5">
			<h1>Tambah Contributor</h1>
			<form action="process/admin/tmbhContri_pros.php" method="post">
				
				Nama Contributor
				<input type="text" name="nama" class="form-control" style="width: 250px;"> <br/> 
				Password
				<input type="Password" name="pass" class="form-control" style="width: 250px;"> <br/>
				<input type="submit" value="Tambah Contributor" class="form-control btn-success" style="width: 160px;">

			</form>
		</div>
	</div>
</div>