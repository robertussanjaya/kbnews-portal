<div class="container">
	<div class="row">
		<div class="col-sm-12 ml-5">
			<h1>Tambah Kategori Berita</h1>
		</div>
		<div class="col-sm-10 col-md-4 ml-5">
			<form action="process/admin/tmbKat_pros.php" method="post">
				
				Kategori Berita : 
				<input type="text" name="nama_kat" class="form-control" style="width: 250px;"> <br/>
				<input type="submit" value="Tambah Kategori" class="form-control btn-success" style="width: 150px;">

			</form>
		</div>
	</div>
</div>