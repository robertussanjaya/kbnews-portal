<div class="container">
	<div class="row">
		<div class="col-sm-10 col-md-4 ml-5">
			<h1>Tambah Admin</h1>
			<form action="process/admin/tmbAdm_pros.php" method="post">
				
				Nama Admin
				<input type="text" name="nama" class="form-control" style="width: 250px;"> <br/> 
				Password
				<input type="Password" name="pass" class="form-control" style="width: 250px;"> <br/>
				<input type="submit" value="Tambah Admin" class="form-control btn-success" style="width: 150px;">

			</form>
		</div>
	</div>
</div>